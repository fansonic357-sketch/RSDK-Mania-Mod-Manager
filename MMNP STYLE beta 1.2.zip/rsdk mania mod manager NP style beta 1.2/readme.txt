============================================================
                 MOD MANAGER BETA 1.2
                  SONIC MANIA MODDING GUIDE
============================================================

Created by: Sa-knawx42

Welcome to MOD MANAGER Beta 1.2!

This README contains tutorials and recommendations for creating Sonic Mania mods.

CONTENTS
------------------------------------------------------------
01. Required Applications
02. How to Create Sprites
03. How to Edit Frames and Animations
04. How to Create and Edit Levels
05. How to Create a game.dll
06. Advanced Modding Ideas
07. How to Test Your Mod
08. Important Recommendations

============================================================
                     01. ENGLISH
============================================================

01. REQUIRED APPLICATIONS
------------------------------------------------------------

Here are some applications you can use to create Sonic Mania mods:

- Maniac Editor:
  Used to edit levels, scenes, objects and other game elements.

- RSDK Animation Editor:
  Used to edit sprite animations, frames, animation speed, loops and sprite properties.

- GraphicsGale:
  Used to draw and edit pixel-art sprites.

- LibreSprite:
  Used to create and edit sprites and animations.

- Visual Studio:
  Used to program and compile advanced modifications.

02. HOW TO CREATE SPRITES
------------------------------------------------------------

1. Open GraphicsGale or LibreSprite.
2. Create a new image.
3. Choose the sprite dimensions.
4. Draw your character, object or effect.
5. Keep the original pixel-art style consistent.
6. Create the remaining animation frames.
7. Export your sprite using a compatible format.
8. Import it into your mod.

TIP:
Keep backup copies of your original sprites.

03. HOW TO EDIT FRAMES AND ANIMATIONS
------------------------------------------------------------

1. Open RSDK Animation Editor.
2. Load your sprite sheet.
3. Select the animation you want to edit.
4. Add, remove or rearrange frames.
5. Adjust the animation speed.
6. Configure the loop settings.
7. Check the sprite position and properties.
8. Save your animation.
9. Test it inside the game.

IMPORTANT:
Check that every frame is visible and that the animation plays correctly.

04. HOW TO CREATE AND EDIT LEVELS
------------------------------------------------------------

1. Open Maniac Editor.
2. Load the appropriate game data.
3. Open the level you want to edit.
4. Modify scenery, tiles, objects and other elements.
5. Save your changes inside your mod.
6. Open the game and test the level.

05. HOW TO CREATE A GAME.DLL
------------------------------------------------------------

ADVANCED MODDING

A game.dll can contain custom code that changes or extends game functionality.

You may need:

- Visual Studio.
- The appropriate RSDKv5 source code.
- A compatible compiler and development environment.
- Knowledge of C or C++.
- Knowledge of the engine's code and interfaces.

GENERAL WORKFLOW:

1. Obtain the appropriate source code.
2. Study the engine's existing systems.
3. Create your custom code.
4. Adapt the project to the correct engine version.
5. Compile using the correct configuration.
6. Test the resulting DLL with a compatible game build.
7. Check for errors and compatibility problems.

IMPORTANT:
Not every game.dll works with every RSDK version.
RSDKv5, RSDKv5U and Sonic Mania Plus may require different builds.

Always keep backups of original files.

06. ADVANCED MODDING IDEAS
------------------------------------------------------------

You can experiment with:

- New character abilities.
- Custom objects.
- New visual effects.
- Custom animations.
- New gameplay mechanics.
- Modified character behaviors.
- New enemies and interactive elements.

07. HOW TO TEST YOUR MOD
------------------------------------------------------------

1. Open MOD MANAGER Beta 1.2.
2. Select your game version.
3. Open Mod Library.
4. Install or select your mod.
5. Use Play Game to launch the game.
6. Test your changes.
7. Check for visual or gameplay errors.

LEVEL SELECT:

Choose a zone and act to prepare the level you want to test.

NOTE:
Direct level launching depends on engine support. Some versions may require you to enter the level manually.

08. IMPORTANT RECOMMENDATIONS
------------------------------------------------------------

- Always make backups.
- Keep your mod files organized.
- Use descriptive file names.
- Test animations before publishing.
- Check compatibility with your selected game version.
- Do not distribute original game files without permission.
- Respect other creators' work.

============================================================
                      02. ESPAÑOL
============================================================

01. APLICACIONES NECESARIAS
------------------------------------------------------------

Estas son algunas aplicaciones que puedes utilizar para crear mods de Sonic Mania:

- Maniac Editor:
  Para editar niveles, escenas, objetos y otros elementos del juego.

- RSDK Animation Editor:
  Para editar animaciones, frames, velocidad, loops y propiedades de sprites.

- GraphicsGale:
  Para dibujar y editar sprites pixel art.

- LibreSprite:
  Para crear y editar sprites y animaciones.

- Visual Studio:
  Para programar y compilar modificaciones avanzadas.

02. CÓMO CREAR SPRITES
------------------------------------------------------------

1. Abre GraphicsGale o LibreSprite.
2. Crea una imagen nueva.
3. Elige las dimensiones del sprite.
4. Dibuja tu personaje, objeto o efecto.
5. Mantén el estilo pixel art del juego.
6. Crea los frames restantes de la animación.
7. Exporta el sprite en un formato compatible.
8. Impórtalo a tu mod.

CONSEJO:
Guarda copias de seguridad de tus sprites originales.

03. CÓMO EDITAR FRAMES Y ANIMACIONES
------------------------------------------------------------

1. Abre RSDK Animation Editor.
2. Carga el sprite sheet.
3. Selecciona la animación que quieras modificar.
4. Añade, elimina o cambia el orden de los frames.
5. Ajusta la velocidad de la animación.
6. Configura el loop.
7. Comprueba la posición y las propiedades del sprite.
8. Guarda la animación.
9. Pruébala dentro del juego.

IMPORTANTE:
Comprueba que todos los frames sean visibles y que la animación funcione correctamente.

04. CÓMO CREAR Y EDITAR NIVELES
------------------------------------------------------------

1. Abre Maniac Editor.
2. Carga los datos correspondientes del juego.
3. Abre el nivel que quieras editar.
4. Modifica escenarios, tiles, objetos y otros elementos.
5. Guarda los cambios dentro de tu mod.
6. Abre el juego y prueba el nivel.

05. CÓMO CREAR UN GAME.DLL
------------------------------------------------------------

MODDING AVANZADO

Un game.dll puede contener código personalizado que modifica o amplía las funciones del juego.

Puedes necesitar:

- Visual Studio.
- El código fuente adecuado de RSDKv5.
- Un compilador y entorno de desarrollo compatibles.
- Conocimientos de C o C++.
- Conocimientos del código y las interfaces del motor.

PROCESO GENERAL:

1. Consigue el código fuente correspondiente.
2. Estudia los sistemas existentes del motor.
3. Crea tu código personalizado.
4. Adapta el proyecto a la versión correcta del motor.
5. Compila con la configuración adecuada.
6. Prueba la DLL con una versión compatible del juego.
7. Comprueba errores y problemas de compatibilidad.

IMPORTANTE:
No todas las DLL funcionan con todas las versiones de RSDK.
RSDKv5, RSDKv5U y Sonic Mania Plus pueden necesitar compilaciones diferentes.

Mantén siempre copias de seguridad de los archivos originales.

06. IDEAS PARA MODS AVANZADOS
------------------------------------------------------------

Puedes experimentar con:

- Nuevas habilidades para personajes.
- Objetos personalizados.
- Nuevos efectos visuales.
- Animaciones personalizadas.
- Nuevas mecánicas de juego.
- Comportamientos modificados de personajes.
- Nuevos enemigos y elementos interactivos.

07. CÓMO PROBAR TU MOD
------------------------------------------------------------

1. Abre MOD MANAGER Beta 1.2.
2. Selecciona la versión del juego.
3. Abre Mod Library.
4. Instala o selecciona tu mod.
5. Usa Play Game para iniciar el juego.
6. Prueba tus modificaciones.
7. Comprueba que no haya errores visuales o de funcionamiento.

LEVEL SELECT:

Selecciona una zona y un acto para preparar el nivel que quieres probar.

NOTA:
El inicio directo de niveles depende de las capacidades del motor. Algunas versiones requieren entrar manualmente al nivel.

08. RECOMENDACIONES IMPORTANTES
------------------------------------------------------------

- Haz siempre copias de seguridad.
- Mantén tus archivos organizados.
- Utiliza nombres descriptivos.
- Prueba las animaciones antes de publicar.
- Comprueba la compatibilidad con la versión seleccionada.
- No distribuyas archivos originales del juego sin permiso.
- Respeta el trabajo de otros creadores.

============================================================
                    03. PORTUGUÊS
============================================================

01. APLICATIVOS NECESSÁRIOS
------------------------------------------------------------

Aqui estão alguns aplicativos que você pode utilizar para criar mods de Sonic Mania:

- Maniac Editor:
  Utilizado para editar fases, cenas, objetos e outros elementos do jogo.

- RSDK Animation Editor:
  Utilizado para editar animações, frames, velocidade, loops e propriedades dos sprites.

- GraphicsGale:
  Utilizado para desenhar e editar sprites em pixel art.

- LibreSprite:
  Utilizado para criar e editar sprites e animações.

- Visual Studio:
  Utilizado para programar e compilar modificações avançadas.

02. COMO CRIAR SPRITES
------------------------------------------------------------

1. Abra o GraphicsGale ou LibreSprite.
2. Crie uma nova imagem.
3. Escolha as dimensões do sprite.
4. Desenhe seu personagem, objeto ou efeito.
5. Mantenha o estilo pixel art do jogo.
6. Crie os frames restantes da animação.
7. Exporte o sprite em um formato compatível.
8. Importe-o para seu mod.

DICA:
Guarde cópias de segurança dos sprites originais.

03. COMO EDITAR FRAMES E ANIMAÇÕES
------------------------------------------------------------

1. Abra o RSDK Animation Editor.
2. Carregue o sprite sheet.
3. Selecione a animação que deseja modificar.
4. Adicione, remova ou reorganize os frames.
5. Ajuste a velocidade da animação.
6. Configure o loop.
7. Verifique a posição e as propriedades do sprite.
8. Salve a animação.
9. Teste-a dentro do jogo.

IMPORTANTE:
Verifique se todos os frames estão visíveis e se a animação funciona corretamente.

04. COMO CRIAR E EDITAR FASES
------------------------------------------------------------

1. Abra o Maniac Editor.
2. Carregue os dados correspondentes do jogo.
3. Abra a fase que deseja editar.
4. Modifique cenários, tiles, objetos e outros elementos.
5. Salve as alterações dentro do seu mod.
6. Abra o jogo e teste a fase.

05. COMO CRIAR UM GAME.DLL
------------------------------------------------------------

MODDING AVANÇADO

Um game.dll pode conter código personalizado que modifica ou amplia as funcionalidades do jogo.

Você pode precisar de:

- Visual Studio.
- O código-fonte adequado do RSDKv5.
- Um compilador e ambiente de desenvolvimento compatíveis.
- Conhecimentos de C ou C++.
- Conhecimentos sobre o código e as interfaces do motor.

PROCESSO GERAL:

1. Obtenha o código-fonte correspondente.
2. Estude os sistemas existentes do motor.
3. Crie seu código personalizado.
4. Adapte o projeto à versão correta do motor.
5. Compile com a configuração adequada.
6. Teste a DLL com uma versão compatível do jogo.
7. Verifique erros e problemas de compatibilidade.

IMPORTANTE:
Nem todas as DLLs funcionam com todas as versões do RSDK.
RSDKv5, RSDKv5U e Sonic Mania Plus podem precisar de compilações diferentes.

Mantenha sempre cópias de segurança dos arquivos originais.

06. IDEIAS PARA MODS AVANÇADOS
------------------------------------------------------------

Você pode experimentar:

- Novas habilidades para personagens.
- Objetos personalizados.
- Novos efeitos visuais.
- Animações personalizadas.
- Novas mecânicas de jogo.
- Comportamentos modificados dos personagens.
- Novos inimigos e elementos interativos.

07. COMO TESTAR SEU MOD
------------------------------------------------------------

1. Abra o MOD MANAGER Beta 1.2.
2. Selecione a versão do jogo.
3. Abra Mod Library.
4. Instale ou selecione seu mod.
5. Use Play Game para iniciar o jogo.
6. Teste suas modificações.
7. Verifique se existem erros visuais ou de funcionamento.

LEVEL SELECT:

Selecione uma zona e um ato para preparar a fase que deseja testar.

OBSERVAÇÃO:
O início direto de uma fase depende dos recursos do motor. Algumas versões exigem que você entre manualmente na fase.

08. RECOMENDAÇÕES IMPORTANTES
------------------------------------------------------------

- Sempre faça cópias de segurança.
- Mantenha seus arquivos organizados.
- Utilize nomes descritivos.
- Teste as animações antes de publicar.
- Verifique a compatibilidade com a versão selecionada.
- Não distribua arquivos originais do jogo sem permissão.
- Respeite o trabalho de outros criadores.

============================================================
                 MOD MANAGER BETA 1.2
============================================================

Created by Sa-knawx42

Thank you for using MOD MANAGER Beta 1.2!

Have fun creating your own Sonic Mania mods!

============================================================
                       END OF README
============================================================